package si.deliva.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final String PREFS = "deliva_v02";
    private static final String KEY_EXPENSES = "expenses";
    private static final String KEY_SETTLEMENTS = "settlements";
    private static final String KEY_NAME_A = "name_a";
    private static final String KEY_NAME_B = "name_b";
    private static final String KEY_SETUP = "setup_done";

    private final int BRAND = Color.rgb(79, 70, 229);
    private final int BRAND_SOFT = Color.rgb(238, 242, 255);
    private final int DARK = Color.rgb(31, 41, 55);
    private final int MUTED = Color.rgb(107, 114, 128);
    private final int BG = Color.rgb(247, 247, 251);
    private final int GREEN = Color.rgb(5, 150, 105);
    private final int RED = Color.rgb(220, 38, 38);
    private final int ORANGE = Color.rgb(217, 119, 6);

    private final String[] categories = {
            "Trgovina", "Hrana", "Otroci", "Dom", "Položnice", "Avto",
            "Gorivo", "Dopust", "Restavracije", "Zdravje", "Zabava", "Drugo"
    };

    private JSONArray expenses = new JSONArray();
    private JSONArray settlements = new JSONArray();
    private String nameA = "Jaz";
    private String nameB = "Partner/ka";
    private Calendar selectedMonth = Calendar.getInstance();
    private String currentScreen = "home";

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        load();
        normalizeSelectedMonth();
        showHome();
        if (!getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY_SETUP, false)) {
            new Handler().postDelayed(() -> showSettings(true), 250);
        }
    }

    private void load() {
        try {
            String rawExpenses = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_EXPENSES, "[]");
            String rawSettlements = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_SETTLEMENTS, "[]");
            expenses = new JSONArray(rawExpenses);
            settlements = new JSONArray(rawSettlements);
        } catch (Exception e) {
            expenses = new JSONArray();
            settlements = new JSONArray();
        }
        nameA = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_NAME_A, "Jaz");
        nameB = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_NAME_B, "Partner/ka");
    }

    private void save() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString(KEY_EXPENSES, expenses.toString())
                .putString(KEY_SETTLEMENTS, settlements.toString())
                .putString(KEY_NAME_A, nameA)
                .putString(KEY_NAME_B, nameB)
                .apply();
    }

    private void normalizeSelectedMonth() {
        selectedMonth.set(Calendar.DAY_OF_MONTH, 1);
        selectedMonth.set(Calendar.HOUR_OF_DAY, 0);
        selectedMonth.set(Calendar.MINUTE, 0);
        selectedMonth.set(Calendar.SECOND, 0);
        selectedMonth.set(Calendar.MILLISECOND, 0);
    }

    private void showHome() {
        currentScreen = "home";
        LinearLayout body = page();
        body.addView(hero());
        body.addView(monthNavigator());

        MonthStats stats = monthStats(selectedMonth);
        body.addView(summaryCard(stats), margin());

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setPadding(dp(16), dp(14), dp(16), 0);

        Button add = primary("+ Dodaj strošek");
        add.setOnClickListener(v -> showExpenseEditor(null));
        actions.addView(add, new LinearLayout.LayoutParams(0, dp(52), 1));

        Button settle = secondary("Poravnaj");
        settle.setOnClickListener(v -> settleMonth(stats));
        LinearLayout.LayoutParams settleParams = new LinearLayout.LayoutParams(0, dp(52), 1);
        settleParams.setMargins(dp(8), 0, 0, 0);
        actions.addView(settle, settleParams);
        body.addView(actions);

        body.addView(section("Stroški v mesecu"));
        List<JSONObject> monthExpenses = expensesForMonth(selectedMonth);
        if (monthExpenses.isEmpty()) {
            body.addView(empty("V tem mesecu še ni stroškov", "Dodaj prvi strošek in Deliva bo takoj izračunala razdelitev."), margin());
        } else {
            for (JSONObject expense : monthExpenses) {
                body.addView(expenseCard(expense), marginSmall());
            }
        }

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setPadding(dp(16), dp(18), dp(16), 0);
        Button overview = secondary("Mesečni pregled");
        overview.setOnClickListener(v -> showOverview());
        nav.addView(overview, new LinearLayout.LayoutParams(0, dp(50), 1));
        Button settings = secondary("Nastavitve");
        settings.setOnClickListener(v -> showSettings(false));
        LinearLayout.LayoutParams settingsParams = new LinearLayout.LayoutParams(0, dp(50), 1);
        settingsParams.setMargins(dp(8), 0, 0, 0);
        nav.addView(settings, settingsParams);
        body.addView(nav);

        body.addView(footer());
        setContentView(wrap(body));
    }

    private View hero() {
        LinearLayout h = new LinearLayout(this);
        h.setOrientation(LinearLayout.VERTICAL);
        h.setPadding(dp(20), dp(26), dp(20), dp(22));
        h.setBackground(round(BRAND, 0));
        h.addView(text("DELIVA", 13, Color.rgb(199, 210, 254), Typeface.BOLD));
        TextView title = text("Skupni stroški. Jasna delitev.", 27, Color.WHITE, Typeface.BOLD);
        title.setPadding(0, dp(6), 0, dp(8));
        h.addView(title);
        h.addView(text(nameA + " + " + nameB, 15, Color.rgb(224, 231, 255), Typeface.NORMAL));
        return h;
    }

    private View monthNavigator() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(14), dp(16), 0);

        Button prev = secondary("‹");
        prev.setOnClickListener(v -> {
            selectedMonth.add(Calendar.MONTH, -1);
            showHome();
        });
        row.addView(prev, new LinearLayout.LayoutParams(dp(52), dp(48)));

        TextView month = text(monthLabel(selectedMonth), 20, DARK, Typeface.BOLD);
        month.setGravity(Gravity.CENTER);
        row.addView(month, new LinearLayout.LayoutParams(0, dp(48), 1));

        Button next = secondary("›");
        next.setOnClickListener(v -> {
            selectedMonth.add(Calendar.MONTH, 1);
            showHome();
        });
        row.addView(next, new LinearLayout.LayoutParams(dp(52), dp(48)));
        return row;
    }

    private View summaryCard(MonthStats s) {
        LinearLayout c = card();
        c.addView(text("Skupaj porabljeno", 13, MUTED, Typeface.BOLD));
        TextView total = text(money(s.total), 30, DARK, Typeface.BOLD);
        total.setPadding(0, dp(3), 0, dp(12));
        c.addView(total);

        LinearLayout paidRow = new LinearLayout(this);
        paidRow.setOrientation(LinearLayout.HORIZONTAL);
        paidRow.addView(statMini(nameA + " plačal/a", money(s.paidA), BRAND), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        LinearLayout.LayoutParams bParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        bParams.setMargins(dp(8), 0, 0, 0);
        paidRow.addView(statMini(nameB + " plačal/a", money(s.paidB), ORANGE), bParams);
        c.addView(paidRow);

        TextView result;
        if (Math.abs(s.balanceA) < 0.01) {
            result = text("Vse je poravnano", 16, GREEN, Typeface.BOLD);
        } else if (s.balanceA > 0) {
            result = text(nameB + " dolguje " + nameA + " " + money(s.balanceA), 16, GREEN, Typeface.BOLD);
        } else {
            result = text(nameA + " dolguje " + nameB + " " + money(-s.balanceA), 16, RED, Typeface.BOLD);
        }
        result.setPadding(0, dp(14), 0, dp(4));
        c.addView(result);

        MonthStats prev = monthStats(shiftedMonth(selectedMonth, -1));
        String comparison;
        int comparisonColor = MUTED;
        if (prev.total <= 0.001) {
            comparison = "Prejšnji mesec ni podatkov";
        } else {
            double change = ((s.total - prev.total) / prev.total) * 100.0;
            comparison = (change >= 0 ? "+" : "") + String.format(Locale.getDefault(), "%.0f %%", change) + " glede na prejšnji mesec";
            comparisonColor = change > 0 ? RED : GREEN;
        }
        c.addView(text(comparison, 13, comparisonColor, Typeface.NORMAL));
        return c;
    }

    private View statMini(String label, String value, int accent) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(12), dp(12), dp(12), dp(12));
        c.setBackground(round(Color.rgb(249, 250, 251), 14));
        c.addView(text(label, 11, MUTED, Typeface.BOLD));
        TextView v = text(value, 17, accent, Typeface.BOLD);
        v.setPadding(0, dp(4), 0, 0);
        c.addView(v);
        return c;
    }

    private View expenseCard(JSONObject e) {
        LinearLayout c = card();
        try {
            String title = e.getString("title");
            double amount = e.getDouble("amount");
            int payer = e.getInt("payer");
            double shareA = e.getDouble("shareA");
            double shareB = amount - shareA;
            String category = e.getString("category");
            long time = e.getLong("time");

            LinearLayout top = new LinearLayout(this);
            top.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout left = new LinearLayout(this);
            left.setOrientation(LinearLayout.VERTICAL);
            left.addView(text(title, 17, DARK, Typeface.BOLD));
            left.addView(text(category + "  •  " + date(time), 12, MUTED, Typeface.NORMAL));
            top.addView(left, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            top.addView(text(money(amount), 18, DARK, Typeface.BOLD));
            c.addView(top);

            String payerName = payer == 0 ? nameA : nameB;
            TextView paid = text("Plačal/a: " + payerName, 13, BRAND, Typeface.BOLD);
            paid.setPadding(0, dp(10), 0, dp(4));
            c.addView(paid);
            c.addView(text("Delitev: " + nameA + " " + money(shareA) + "  •  " + nameB + " " + money(shareB), 13, MUTED, Typeface.NORMAL));

            LinearLayout buttons = new LinearLayout(this);
            buttons.setOrientation(LinearLayout.HORIZONTAL);
            buttons.setPadding(0, dp(10), 0, 0);
            Button edit = secondary("Uredi");
            edit.setOnClickListener(v -> showExpenseEditor(e));
            buttons.addView(edit, new LinearLayout.LayoutParams(0, dp(42), 1));
            Button delete = secondary("Izbriši");
            delete.setOnClickListener(v -> confirmDeleteExpense(e.optString("id")));
            LinearLayout.LayoutParams delParams = new LinearLayout.LayoutParams(0, dp(42), 1);
            delParams.setMargins(dp(8), 0, 0, 0);
            buttons.addView(delete, delParams);
            c.addView(buttons);
        } catch (Exception ignored) {
        }
        return c;
    }

    private void showExpenseEditor(JSONObject existing) {
        boolean editing = existing != null;
        LinearLayout form = form();

        EditText title = input("npr. Tedenski nakup");
        EditText amount = input("0,00");
        amount.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);

        Spinner category = spinner(categories);
        Spinner payer = spinner(new String[]{nameA, nameB});
        String[] splitOptions = {"50 / 50", nameA + " 100 %", nameB + " 100 %", "Po meri"};
        Spinner split = spinner(splitOptions);
        EditText percentA = input("50");
        percentA.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);

        final Calendar expenseDate = Calendar.getInstance();
        Button dateButton = secondary(date(expenseDate.getTimeInMillis()));
        dateButton.setOnClickListener(v -> new DatePickerDialog(this, (view, year, month, day) -> {
            expenseDate.set(year, month, day, 12, 0, 0);
            dateButton.setText(date(expenseDate.getTimeInMillis()));
        }, expenseDate.get(Calendar.YEAR), expenseDate.get(Calendar.MONTH), expenseDate.get(Calendar.DAY_OF_MONTH)).show());

        if (editing) {
            try {
                title.setText(existing.getString("title"));
                amount.setText(String.format(Locale.US, "%.2f", existing.getDouble("amount")));
                payer.setSelection(existing.getInt("payer"));
                expenseDate.setTimeInMillis(existing.getLong("time"));
                dateButton.setText(date(expenseDate.getTimeInMillis()));
                selectSpinner(category, existing.getString("category"));
                double total = existing.getDouble("amount");
                double aPercent = total <= 0 ? 50 : existing.getDouble("shareA") / total * 100.0;
                if (Math.abs(aPercent - 50) < 0.01) split.setSelection(0);
                else if (Math.abs(aPercent - 100) < 0.01) split.setSelection(1);
                else if (Math.abs(aPercent) < 0.01) split.setSelection(2);
                else split.setSelection(3);
                percentA.setText(String.format(Locale.US, "%.0f", aPercent));
            } catch (Exception ignored) {
            }
        }

        split.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) percentA.setText("50");
                if (position == 1) percentA.setText("100");
                if (position == 2) percentA.setText("0");
                percentA.setEnabled(position == 3);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        form.addView(label("Opis stroška"));
        form.addView(title, field());
        form.addView(label("Znesek (€)"));
        form.addView(amount, field());
        form.addView(label("Datum"));
        form.addView(dateButton, field());
        form.addView(label("Kategorija"));
        form.addView(category, field());
        form.addView(label("Kdo je plačal?"));
        form.addView(payer, field());
        form.addView(label("Način delitve"));
        form.addView(split, field());
        form.addView(label("Delež za " + nameA + " (%)"));
        form.addView(percentA, field());

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(editing ? "Uredi strošek" : "Nov strošek")
                .setView(form)
                .setNegativeButton("Prekliči", null)
                .setPositiveButton("Shrani", null)
                .create();

        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            try {
                String titleValue = title.getText().toString().trim();
                double amountValue = Double.parseDouble(amount.getText().toString().replace(',', '.'));
                double percentValue = Double.parseDouble(percentA.getText().toString().replace(',', '.'));
                if (titleValue.isEmpty() || amountValue <= 0 || percentValue < 0 || percentValue > 100) {
                    toast("Preveri opis, znesek in delež.");
                    return;
                }

                JSONObject target = editing ? existing : new JSONObject();
                if (!editing) target.put("id", UUID.randomUUID().toString());
                target.put("title", titleValue);
                target.put("amount", amountValue);
                target.put("time", expenseDate.getTimeInMillis());
                target.put("category", category.getSelectedItem().toString());
                target.put("payer", payer.getSelectedItemPosition());
                target.put("shareA", amountValue * percentValue / 100.0);

                if (!editing) expenses.put(target);
                save();
                selectedMonth.setTimeInMillis(expenseDate.getTimeInMillis());
                normalizeSelectedMonth();
                dialog.dismiss();
                showHome();
            } catch (Exception ex) {
                toast("Podatki niso veljavni.");
            }
        }));
        dialog.show();
    }

    private void settleMonth(MonthStats stats) {
        if (Math.abs(stats.balanceA) < 0.01) {
            toast("Ta mesec je že poravnan.");
            return;
        }
        String message;
        int from;
        int to;
        double amount = Math.abs(stats.balanceA);
        if (stats.balanceA > 0) {
            from = 1;
            to = 0;
            message = nameB + " plača " + nameA + " " + money(amount) + ".";
        } else {
            from = 0;
            to = 1;
            message = nameA + " plača " + nameB + " " + money(amount) + ".";
        }
        new AlertDialog.Builder(this)
                .setTitle("Potrdi poravnavo")
                .setMessage(message + "\n\nPoravnava bo shranjena v izbranem mesecu.")
                .setNegativeButton("Prekliči", null)
                .setPositiveButton("Poravnano", (d, w) -> {
                    try {
                        JSONObject s = new JSONObject();
                        s.put("id", UUID.randomUUID().toString());
                        s.put("from", from);
                        s.put("to", to);
                        s.put("amount", amount);
                        Calendar date = (Calendar) selectedMonth.clone();
                        date.set(Calendar.DAY_OF_MONTH, Math.min(Calendar.getInstance().get(Calendar.DAY_OF_MONTH), date.getActualMaximum(Calendar.DAY_OF_MONTH)));
                        date.set(Calendar.HOUR_OF_DAY, 12);
                        s.put("time", date.getTimeInMillis());
                        settlements.put(s);
                        save();
                        showHome();
                    } catch (Exception e) {
                        toast("Poravnave ni bilo mogoče shraniti.");
                    }
                }).show();
    }

    private void confirmDeleteExpense(String id) {
        new AlertDialog.Builder(this)
                .setTitle("Izbrišem strošek?")
                .setMessage("Tega dejanja ni mogoče razveljaviti.")
                .setNegativeButton("Ne", null)
                .setPositiveButton("Izbriši", (d, w) -> {
                    JSONArray next = new JSONArray();
                    for (int i = 0; i < expenses.length(); i++) {
                        JSONObject e = expenses.optJSONObject(i);
                        if (e != null && !id.equals(e.optString("id"))) next.put(e);
                    }
                    expenses = next;
                    save();
                    showHome();
                }).show();
    }

    private void showOverview() {
        currentScreen = "overview";
        LinearLayout body = page();
        body.addView(topBar("Mesečni pregled", this::showHome));

        Calendar month = Calendar.getInstance();
        month.set(Calendar.DAY_OF_MONTH, 1);
        for (int i = 0; i < 12; i++) {
            MonthStats s = monthStats(month);
            LinearLayout c = card();
            LinearLayout top = new LinearLayout(this);
            top.setGravity(Gravity.CENTER_VERTICAL);
            top.addView(text(monthLabel(month), 17, DARK, Typeface.BOLD), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            top.addView(text(money(s.total), 18, s.total > 0 ? DARK : MUTED, Typeface.BOLD));
            c.addView(top);
            c.addView(text(nameA + ": " + money(s.paidA) + "  •  " + nameB + ": " + money(s.paidB), 13, MUTED, Typeface.NORMAL));
            String settlement;
            int color;
            if (Math.abs(s.balanceA) < 0.01) {
                settlement = "Poravnano";
                color = GREEN;
            } else if (s.balanceA > 0) {
                settlement = nameB + " → " + nameA + ": " + money(s.balanceA);
                color = GREEN;
            } else {
                settlement = nameA + " → " + nameB + ": " + money(-s.balanceA);
                color = RED;
            }
            TextView st = text(settlement, 13, color, Typeface.BOLD);
            st.setPadding(0, dp(7), 0, 0);
            c.addView(st);
            final Calendar target = (Calendar) month.clone();
            c.setOnClickListener(v -> {
                selectedMonth = (Calendar) target.clone();
                showHome();
            });
            body.addView(c, marginSmall());
            month.add(Calendar.MONTH, -1);
        }

        body.addView(section("Poraba po kategorijah – " + monthLabel(selectedMonth)));
        LinearLayout categoryCard = card();
        List<CategoryTotal> totals = categoryTotals(selectedMonth);
        if (totals.isEmpty()) {
            categoryCard.addView(text("V izbranem mesecu ni podatkov.", 14, MUTED, Typeface.NORMAL));
        } else {
            for (CategoryTotal ct : totals) {
                LinearLayout row = new LinearLayout(this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(0, dp(6), 0, dp(6));
                row.addView(text(ct.name, 14, DARK, Typeface.BOLD), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
                row.addView(text(money(ct.total), 14, BRAND, Typeface.BOLD));
                categoryCard.addView(row);
            }
        }
        body.addView(categoryCard, margin());
        body.addView(footer());
        setContentView(wrap(body));
    }

    private void showSettings(boolean firstRun) {
        LinearLayout form = form();
        EditText a = input(nameA);
        a.setText(nameA);
        EditText b = input(nameB);
        b.setText(nameB);
        form.addView(label("Prva oseba"));
        form.addView(a, field());
        form.addView(label("Druga oseba"));
        form.addView(b, field());

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(firstRun ? "Nastavi Delivo" : "Nastavitve")
                .setMessage(firstRun ? "Vnesi imeni oseb, med katerima boš delil/a stroške." : null)
                .setView(form)
                .setNegativeButton(firstRun ? "Pozneje" : "Prekliči", null)
                .setPositiveButton("Shrani", null)
                .create();

        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String av = a.getText().toString().trim();
            String bv = b.getText().toString().trim();
            if (av.isEmpty() || bv.isEmpty()) {
                toast("Vnesi obe imeni.");
                return;
            }
            nameA = av;
            nameB = bv;
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_SETUP, true).apply();
            save();
            dialog.dismiss();
            showHome();
        }));
        dialog.show();
    }

    private MonthStats monthStats(Calendar month) {
        MonthStats s = new MonthStats();
        for (int i = 0; i < expenses.length(); i++) {
            JSONObject e = expenses.optJSONObject(i);
            if (e == null || !sameMonth(e.optLong("time"), month)) continue;
            double amount = e.optDouble("amount", 0);
            double shareA = e.optDouble("shareA", amount / 2.0);
            int payer = e.optInt("payer", 0);
            s.total += amount;
            if (payer == 0) s.paidA += amount;
            else s.paidB += amount;
            s.balanceA += (payer == 0 ? amount : 0) - shareA;
        }
        for (int i = 0; i < settlements.length(); i++) {
            JSONObject st = settlements.optJSONObject(i);
            if (st == null || !sameMonth(st.optLong("time"), month)) continue;
            double amount = st.optDouble("amount", 0);
            int from = st.optInt("from", 0);
            if (from == 0) s.balanceA += amount;
            else s.balanceA -= amount;
        }
        return s;
    }

    private List<JSONObject> expensesForMonth(Calendar month) {
        List<JSONObject> list = new ArrayList<>();
        for (int i = 0; i < expenses.length(); i++) {
            JSONObject e = expenses.optJSONObject(i);
            if (e != null && sameMonth(e.optLong("time"), month)) list.add(e);
        }
        Collections.sort(list, (a, b) -> Long.compare(b.optLong("time"), a.optLong("time")));
        return list;
    }

    private List<CategoryTotal> categoryTotals(Calendar month) {
        List<CategoryTotal> list = new ArrayList<>();
        for (String category : categories) {
            double total = 0;
            for (int i = 0; i < expenses.length(); i++) {
                JSONObject e = expenses.optJSONObject(i);
                if (e != null && sameMonth(e.optLong("time"), month) && category.equals(e.optString("category"))) {
                    total += e.optDouble("amount", 0);
                }
            }
            if (total > 0.001) list.add(new CategoryTotal(category, total));
        }
        list.sort((a, b) -> Double.compare(b.total, a.total));
        return list;
    }

    private boolean sameMonth(long time, Calendar month) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(time);
        return c.get(Calendar.YEAR) == month.get(Calendar.YEAR) && c.get(Calendar.MONTH) == month.get(Calendar.MONTH);
    }

    private Calendar shiftedMonth(Calendar source, int delta) {
        Calendar c = (Calendar) source.clone();
        c.add(Calendar.MONTH, delta);
        return c;
    }

    private View topBar(String title, Runnable backAction) {
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(16), dp(16), dp(16), dp(8));
        Button back = secondary("‹ Nazaj");
        back.setOnClickListener(v -> backAction.run());
        bar.addView(back, new LinearLayout.LayoutParams(dp(105), dp(46)));
        TextView t = text(title, 22, DARK, Typeface.BOLD);
        t.setPadding(dp(12), 0, 0, 0);
        bar.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        return bar;
    }

    private LinearLayout page() {
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setBackgroundColor(BG);
        p.setPadding(0, 0, 0, dp(24));
        return p;
    }

    private ScrollView wrap(View v) {
        ScrollView s = new ScrollView(this);
        s.setFillViewport(true);
        s.setBackgroundColor(BG);
        s.addView(v);
        return s;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(16), dp(16), dp(16));
        c.setBackground(round(Color.WHITE, 18));
        c.setElevation(dp(2));
        return c;
    }

    private LinearLayout empty(String title, String subtitle) {
        LinearLayout c = card();
        c.setGravity(Gravity.CENTER);
        TextView a = text(title, 17, DARK, Typeface.BOLD);
        a.setGravity(Gravity.CENTER);
        c.addView(a);
        TextView b = text(subtitle, 13, MUTED, Typeface.NORMAL);
        b.setGravity(Gravity.CENTER);
        b.setPadding(0, dp(6), 0, 0);
        c.addView(b);
        return c;
    }

    private TextView section(String s) {
        TextView t = text(s, 18, DARK, Typeface.BOLD);
        t.setPadding(dp(16), dp(22), dp(16), dp(6));
        return t;
    }

    private TextView footer() {
        TextView t = text("Deliva v0.2  •  Podatki ostanejo samo na tej napravi", 12, MUTED, Typeface.NORMAL);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(16), dp(28), dp(16), dp(10));
        return t;
    }

    private LinearLayout form() {
        LinearLayout f = new LinearLayout(this);
        f.setOrientation(LinearLayout.VERTICAL);
        f.setPadding(dp(22), dp(4), dp(22), dp(12));
        return f;
    }

    private TextView label(String s) {
        TextView t = text(s, 12, DARK, Typeface.BOLD);
        t.setPadding(0, dp(10), 0, dp(4));
        return t;
    }

    private EditText input(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setTextSize(15);
        e.setPadding(dp(12), 0, dp(12), 0);
        e.setBackground(round(Color.rgb(245, 247, 250), 12));
        return e;
    }

    private Spinner spinner(String[] values) {
        Spinner s = new Spinner(this);
        s.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, values));
        s.setPadding(dp(8), 0, dp(8), 0);
        s.setBackground(round(Color.rgb(245, 247, 250), 12));
        return s;
    }

    private void selectSpinner(Spinner spinner, String value) {
        for (int i = 0; i < spinner.getCount(); i++) {
            if (value.equals(spinner.getItemAtPosition(i).toString())) {
                spinner.setSelection(i);
                return;
            }
        }
    }

    private Button primary(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(round(BRAND, 14));
        return b;
    }

    private Button secondary(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(BRAND);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(round(BRAND_SOFT, 14));
        return b;
    }

    private TextView text(String s, int size, int color, int style) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT, style);
        t.setIncludeFontPadding(false);
        return t;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        return g;
    }

    private LinearLayout.LayoutParams margin() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(dp(16), dp(14), dp(16), 0);
        return p;
    }

    private LinearLayout.LayoutParams marginSmall() {
        LinearLayout.LayoutParams p = margin();
        p.topMargin = dp(9);
        return p;
    }

    private LinearLayout.LayoutParams field() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
    }

    private int dp(int n) {
        return Math.round(n * getResources().getDisplayMetrics().density);
    }

    private String money(double v) {
        return NumberFormat.getCurrencyInstance(new Locale("sl", "SI")).format(v);
    }

    private String date(long t) {
        return new SimpleDateFormat("dd.MM.yyyy", new Locale("sl", "SI")).format(new Date(t));
    }

    private String monthLabel(Calendar c) {
        String raw = new SimpleDateFormat("MMMM yyyy", new Locale("sl", "SI")).format(c.getTime());
        return raw.substring(0, 1).toUpperCase(new Locale("sl", "SI")) + raw.substring(1);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onBackPressed() {
        if (!"home".equals(currentScreen)) showHome();
        else super.onBackPressed();
    }

    private static class MonthStats {
        double total;
        double paidA;
        double paidB;
        double balanceA;
    }

    private static class CategoryTotal {
        final String name;
        final double total;

        CategoryTotal(String name, double total) {
            this.name = name;
            this.total = total;
        }
    }
}
